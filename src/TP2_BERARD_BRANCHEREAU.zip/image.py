from skimage import io
from skimage.transform import resize
import matplotlib.pyplot as plt
import numpy as np

class Image:
    def __init__(self):
        """Initialisation d'une image composee d'un tableau numpy 2D vide
        (pixels) et de 2 dimensions (H = height et W = width) mises a 0
        """
        self.pixels = None
        self.H = 0
        self.W = 0
    

    def set_pixels(self, tab_pixels):
        """ Remplissage du tableau pixels de l'image self avec un tableau 2D (tab_pixels)
        et affectation des dimensions de l'image self avec les dimensions 
        du tableau 2D (tab_pixels) 
        """
        self.pixels = tab_pixels
        self.H, self.W = self.pixels.shape


    def load(self, file_name):
        """ Lecture d'un image a partir d'un fichier de nom "file_name"""
        self.pixels = io.imread(file_name)
        self.H,self.W = self.pixels.shape 
        print("lecture image : " + file_name + " (" + str(self.H) + "x" + str(self.W) + ")")


    def display(self, window_name):
        """Affichage a l'ecran d'une image"""
        fig = plt.figure(window_name)
        if (not (self.pixels is None)):
            io.imshow(self.pixels)
            io.show()
        else:
            print("L'image est vide. Rien à afficher")


    #==============================================================================
    # Methode de binarisation
    # 2 parametres :
    #   self : l'image a binariser
    #   S : le seuil de binarisation
    #   on retourne une nouvelle image binarisee
    #==============================================================================
    def binarisation(self, S):
        image_binaire = Image()
        #on initialise un nouveau tableau 
        
        image_binaire.set_pixels(np.zeros((self.H, self.W), dtype=np.uint8))
        #création d'un tableau de pixel de même taille que pixel
        
        for i in range(self.H):
            #on parcourt toutes les lignes de notre tableau
            for j in range(self.W):
                 #on parcourt toutes les colonnes de notre tableau
                 if self.pixels[i][j] >= S:
                     image_binaire.pixels[i][j] = 255
                     #dans le nouveau tableau, si le pixels à une valeur supérieur ou égal à notre seuil S
                     #il prend la valeur de 255 (blanc)
                 else:
                     image_binaire.pixels[i][j] = 0
                     #sinon il prend la valeur 0 (noir)
        return image_binaire


    #==============================================================================
    # Dans une image binaire contenant une forme noire sur un fond blanc
    # la methode 'localisation' permet de limiter l'image au rectangle englobant
    # la forme noire
    # 1 parametre :
    #   self : l'image binaire que l'on veut recadrer
    #   on retourne une nouvelle image recadree
    #==============================================================================
    def localisation(self):
        image_localisee = Image()
        #on initialise un nouveau tableau 
        image_localisee.set_pixels(np.zeros((self.H, self.W), dtype=np.uint8))
        #création d'un tableau de pixel de même taille que pixel
        
        l_min = self.H
        l_max = 0
        #initialise les limites de ma figure sur H
        c_min = self.W
        c_max = 0
        #initialise les limites de ma figure sur W
        
        #Boucle pour les lignes
        for i in range(self.H):
            #on parcourt toutes les lignes de notre tableau
            l_min_ligne = self.H
            l_max_ligne = 0
            #on initialise deux variables utilisées propre à chaque ligne
            for j in range(1,self.W):
                 #on parcourt toutes les colonnes de notre tableau
                 if self.pixels[i][j]<self.pixels[i][j-1] and l_max_ligne == 0:
                     l_min_ligne = i
                     # si on est passé de blanc à noir et qu'il n'y jamais eu de passage noir/blanc 
                     #alors on prend la valeur de i
                 elif self.pixels[i][j]>self.pixels[i][j-1]:
                     l_max_ligne = i
                     #si on passe de noir/blanc alors on prend la valeur de i
                     
            #on compare avec la valeur des limites
            if l_max_ligne > l_max:
                l_max = l_max_ligne
            if l_min_ligne < l_min:
                l_min = l_min_ligne
        
        #Boucle pour les colonnes
        for i in range(1,self.H):
            #on parcourt toutes les lignes de notre tableau
            c_min_colonne = self.W
            c_max_colonne = 0
            #on initialise deux variables utilisées propre à chaque colonne
            for j in range(self.W):
                 #on parcourt toutes les colonnes de notre tableau
                 if self.pixels[i][j]<self.pixels[i-1][j] and c_max_colonne == 0:
                     c_min_colonne = j
                     # si on est passé de blanc à noir et qu'il n'y jamais eu de passage noir/blanc 
                     #alors on prend la valeur de i
                 elif self.pixels[i][j]>self.pixels[i-1][j]:
                     c_max_colonne = j
                     #si on passe de noir/blanc alors on prend la valeur de i
                     
            #on compare avec la valeur des limites
            if c_max_colonne > c_max:
                c_max = c_max_colonne
            if c_min_colonne < c_min:
                c_min = c_min_colonne
        
        image_localisee.set_pixels(self.pixels[l_min:l_max+1,c_min:c_max+1])
        # l'image localisée est donc l'image initiale bornée aux limites
        
        return image_localisee

    #==============================================================================
    # Methode de redimensionnement d'image
    #==============================================================================
    def resize(self, new_H, new_W):
        image_resized = Image()
        #on initialise un nouveau tableau 
        image_resized.set_pixels(np.zeros((self.H, self.W), dtype=np.uint8))
        #création d'un tableau de pixel de même taille que pixel
        image_resized.set_pixels(resize(self.pixels, (new_H, new_W), 0))
        return image_resized 


    #==============================================================================
    # Methode de mesure de similitude entre l'image self et un modele im
    #==============================================================================
    def similitude(self, im):
        #la fonction va retourner une valeur de 0 à 1
        nb_pixels = self.H*self.W
        n = 0 #compteur de pixels similaires
        
        for i in range(self.H):
            #on parcourt toutes les lignes de notre tableau
            for j in range(self.W):
                #on parcourt toutes les colonnes de notre tableau
                if self.pixels[i][j] == im.pixels[i][j]:
                    n += 1
                    #si les pixels au même endroit sont de même intensité 
                    #alors on incrémente n
        return n/nb_pixels

